﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02
{
    class Program
    {
        //Main
        static void Main(string[] args)
        {

            //variables 
            int selectCoating;
            int selectGlasses;

            //price coatings
            var coatingPrices = new Dictionary<int, decimal>();
            coatingPrices.Add(1, 12.5M);
            coatingPrices.Add(2, 9.99M);

         
            var glassesPrices = new Dictionary<int, decimal>();
            glassesPrices.Add(1, 40);
            glassesPrices.Add(2, 25);

           

            Console.WriteLine("What kind of glasses would you like:");
            do
            {
                Console.Write("1 -> prescription, 2 -> non-prescription : ");
            }
            while (!Int32.TryParse(Console.ReadLine(), out selectGlasses) || !glassesPrices.ContainsKey(selectGlasses));

            
            Console.WriteLine("What kind of coating would you like:");
            do
            {
                string messageToDisplay = "";

                if (!checkForCoatingRequirement(selectGlasses))
                {
                    messageToDisplay += "0 -> No coating, ";
                }

                Console.Write(messageToDisplay + "1 -> anti-glare, 2 -> brown tint : ");
            }
            while (!Int32.TryParse(Console.ReadLine(), out selectCoating) || !validityCheckCoatingSelection(selectCoating, selectGlasses, coatingPrices));

            //Total cost
            Console.WriteLine($"Your total cost is ${glassesPrices[selectGlasses] + (coatingPrices.ContainsKey(selectCoating) ? coatingPrices[selectCoating] : 0)}");

            
            Console.Read();
        }

        //Check for coating requirement, returns true or false
        public static bool checkForCoatingRequirement(int typeOfGlasses)
        {
            int[] glassesRequiringCoating = { 1 };
            bool check = glassesRequiringCoating.Contains(typeOfGlasses);
            return check;
        }

        //coating selection validation, return true or false
        public static bool validityCheckCoatingSelection(int coatingSelection, int glassesSelection, IDictionary<int, decimal> pricesForCoatings)
        {
            return checkForCoatingRequirement(glassesSelection) ? pricesForCoatings.ContainsKey(coatingSelection) : true;
        }
    }
}