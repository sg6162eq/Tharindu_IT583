﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tharindu_Lab_C
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * Response to questions from instructions
             * 
             * 2. They are Different elements, but it will get the same results.
             * 
             * 5. None of the if-else statements to be written in block form if they only contain one line.
             * so IF statemnts will be executalble for this scenario.
             */

            Console.WriteLine("CS 201 Restaurant Guide\n");

            string Response;
            char S, F;
            bool Spicy, Fancy;

            // Ask user for his/her preference
            Console.Write("Do you like spicy food? (y / n) : ");
            // Get the next token
            Response = Console.ReadLine();
            // Look only at first character
            S = Response[0];
            if (S.Equals('y') || S.Equals('Y'))
            {
                Spicy = true;
            }
            else
            {
                Spicy = false;
            }

            // Ask user for his/her preference
            Console.Write("Do you want to go to a fancy restaurant? (y / n) : ");
            // Get the next token
            Response = Console.ReadLine();
            // Look only at first character
            F = Response[0];
            Fancy = F.Equals('y') || F.Equals('Y');

            // Make suggestion
            if (Spicy && Fancy)
            {
                Console.WriteLine("I suggest you go to Thai Garden Palace.");
            }
            else
            {
                if (!Spicy && !Fancy)
                {
                    Console.WriteLine("I suggest you go to Joe's Diner.");
                }
                else
                {
                    if (Spicy && !Fancy)
                    {
                        Console.WriteLine("I suggest you go to Alberto's Tacqueria.");
                    }
                    else
                    {
                        if (!Spicy && Fancy)
                        {
                            Console.WriteLine("I suggest you go to Chez Paris.");
                        }
                    }
                }
            }


            Console.Read();
        }
    }
}
